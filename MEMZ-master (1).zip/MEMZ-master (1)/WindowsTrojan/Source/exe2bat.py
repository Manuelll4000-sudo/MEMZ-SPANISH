# Very poorly coded exe (or other file) to batch converter.
#
# If you want to use it, don't forget to append -zip to the command line,
# because this is the best method for packing the file.

import sys, os, base64, zipfile

use_zip = "-zip" in sys.argv
for_xp = "-xp" in sys.argv
use_script = "-zip" in sys.argv or "-xp" in sys.argv

ZIP_NAME = "z.zip"
EXE_NAME = sys.argv[3]
BASE64_NAME = "x"
JS_NAME = "x.js"

def writeScript(script, path):
	out = ""
	i = 0
	
	for line in script.splitlines():
		if i == 0:
			out += 'echo %s>%s\r\n' % (batchescape(line), path)
		else:
			out += 'echo %s>>%s\r\n' % (batchescape(line), path)
		i += 1
		
	return out
	
def batchescape(s):
	chrs = '<>|"&'
	for c in chrs:
		s = s.replace(c, "^"+c)
	return s  # "%"" no necesita reemplazo

out = "@echo off\r\n\r\n"

fn = sys.argv[1]

if use_zip:
	with zipfile.ZipFile("temp.zip", "w") as z:
		z.write(sys.argv[1], EXE_NAME, zipfile.ZIP_DEFLATED)
	fn = "temp.zip"

with open(fn, "rb") as ifile:
	inp = ifile.read()

b64 = base64.encodebytes(inp).decode("utf-8")
out += writeScript(b64, BASE64_NAME)

if use_zip:
	os.remove("temp.zip")

if use_script:
	out += "\r\n"

if use_zip:
	js = f"""f=new ActiveXObject("Scripting.FileSystemObject");i=f.getFile("{BASE64_NAME}").openAsTextStream();
x=new ActiveXObject("MSXml2.DOMDocument").createElement("Base64Data");x.dataType="bin.base64";
x.text=i.readAll();o=new ActiveXObject("ADODB.Stream");o.type=1;o.open();o.write(x.nodeTypedValue);
z=f.getAbsolutePathName("{ZIP_NAME}");o.saveToFile(z);s=new ActiveXObject("Shell.Application");
s.namespace(26).copyHere(s.namespace(z).items());o.close();i.close();"""

	out += writeScript(js, JS_NAME)

elif for_xp:
	js = f"""i=WScript.createObject("Scripting.FileSystemObject").getFile("{BASE64_NAME}").openAsTextStream();
x=WScript.createObject("MSXml2.DOMDocument").createElement("Base64Data");x.dataType="bin.base64";
x.text=i.readAll();o=WScript.createObject("ADODB.Stream");o.type=1;o.open();o.write(x.nodeTypedValue);
o.saveToFile("{EXE_NAME}");o.close();i.close();"""

	out += writeScript(js, JS_NAME)

out += "\r\n"
out += f'set v="%%appdata%%\\{EXE_NAME}"\r\n'
out += "del %v% >NUL 2>NUL\r\n"

if use_script:
	out += f"cscript {JS_NAME} >NUL 2>NUL\r\n"
	out += f"del {JS_NAME} >NUL 2>NUL\r\n"
else:
	out += f"certutil -decode {BASE64_NAME} %v% >NUL 2>NUL\r\n"

if for_xp:
	out += f"move {EXE_NAME} %v% >NUL 2>NUL\r\n"

if use_zip:
	out += f"del {ZIP_NAME} >NUL 2>NUL\r\n"

out += f"del {BASE64_NAME} >NUL 2>NUL\r\n"
out += 'start "" %v%'

with open(sys.argv[2], "wb") as ofile:
	ofile.write(out.encode("utf-8"))

print(len(out), "characters.")
